# NEXORA security notes
- No server, database, accounts or API keys: nothing to breach server-side, and no user data leaves the browser.
- Strict CSP (hash-based, no eval, no external hosts), set in index.html and in _headers / vercel.json.
- Calculator uses a small parser instead of eval; stored settings and favourites are validated on load; JSON errors are escaped.
- Service worker caches same-origin GET requests only.
- Headers (frame-ancestors, HSTS, nosniff, COOP/CORP) only apply when your host sends them: use _headers (Netlify, Cloudflare Pages) or vercel.json, or copy them into your nginx/Apache config. Serve over HTTPS only.
- After editing index.html run: python3 build-csp.py
- No site can be guaranteed unhackable. Keep the host account protected with 2FA and review changes before deploying.

## Backend (server.js)
- API keys only in server environment variables; never sent to the browser or written to disk. Tested: keys do not appear in any page or API response, including provider error cases.
- Live AI requires explicit consent per request; prompt limited to 4000 chars, body to 16 KB; per-IP rate limit; same-origin check (set ALLOWED_ORIGIN if needed); 30 s upstream timeout; generic error messages; no prompt/answer logging.
- Only index.html, manifest.json, sw.js and icon.svg are served; everything else is 404.
- Not verified against the real provider APIs (tested with a local stand-in). Test with your own key.
