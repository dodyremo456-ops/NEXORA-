# Deploy NEXORA AI Lab

## Recommended: Render (website + Node backend)

This project includes `render.yaml` and `package.json` for a Node web service. The site can be published without an AI key; live AI remains disabled until you add a provider key.

1. Put the **contents of this folder** in a GitHub repository (so `render.yaml`, `package.json`, `server.js`, and `index.html` are in the repository root).
2. In Render, create a new Blueprint and select that repository. Review the service settings before deploying.
3. Wait for the deploy to finish, then open the generated HTTPS URL. The `/api/status` endpoint is the health check.
4. To enable live AI, open the service's Environment settings and add **one** provider key as a secret environment variable: `OPENAI_API_KEY` or `ANTHROPIC_API_KEY`. Optionally set `OPENAI_MODEL` or `ANTHROPIC_MODEL` to a model available to that API account. Redeploy/restart the service after saving.
5. Do not paste API keys into chat, commit them to GitHub, put them in HTML, or add them to `render.yaml`. Add them only in the hosting provider's secret environment settings.

## Costs and privacy

- Hosting plan limits and AI provider billing can change. Check the current plan and API pricing before enabling paid API calls. An API key may allow billable use.
- The website asks for consent before sending a prompt. The backend does not intentionally store prompts or answers, but the hosting provider may record request metadata such as IP address and time.
- Use HTTPS and protect the hosting and GitHub accounts.

## Local run (Windows / PowerShell)

From this folder, run:

```powershell
node --check server.js
node server.js
```

Then open `http://127.0.0.1:8080`. Without a provider key, the site loads normally and live AI remains off. For a local key, set it only in the current PowerShell session before starting the server; never save it in project files.

## Other hosting

`vercel.json` currently supplies security headers for a static deployment; it does not deploy this custom Node server as a Vercel serverless API. Use a Node web-service host for the combined website and backend, or expect live AI to remain unavailable on static-only hosting.
