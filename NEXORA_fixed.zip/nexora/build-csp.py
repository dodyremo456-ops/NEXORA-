# Run after editing index.html: python3 build-csp.py
# Recomputes the CSP hashes in index.html, _headers and vercel.json.
import re,hashlib,base64,json
b=open("index.html",encoding="utf-8").read()
h=lambda x:"'sha256-"+base64.b64encode(hashlib.sha256(x.encode()).digest()).decode()+"'"
sc=re.findall(r"<script>(.*?)</script>",b,re.S)[0];st=re.findall(r"<style>(.*?)</style>",b,re.S)[0]
new=re.sub(r"script-src 'sha256-[^']+'","script-src "+h(sc),b);new=re.sub(r"style-src-elem 'sha256-[^']+'","style-src-elem "+h(st),new)
open("index.html","w",encoding="utf-8").write(new)
for f in ("_headers","vercel.json"):
    t=open(f).read();t=re.sub(r"script-src 'sha256-[^']+'","script-src "+h(sc),t);t=re.sub(r"style-src-elem 'sha256-[^']+'","style-src-elem "+h(st),t);open(f,"w").write(t)
print("hashes updated")
