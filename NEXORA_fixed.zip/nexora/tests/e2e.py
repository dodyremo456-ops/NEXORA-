from playwright.sync_api import sync_playwright
import json
U='http://localhost:8765/index.html'
R=[];err=[]
def ok(n,c,d=''): R.append((n,bool(c),d))
with sync_playwright() as p:
    b=p.chromium.launch();ctx=b.new_context(viewport={'width':1440,'height':900});ctx.grant_permissions([]);pg=ctx.new_page()
    pg.on('console',lambda m:err.append(m.text) if m.type in('error','warning') else None)
    pg.on('pageerror',lambda e:err.append('PAGEERR '+str(e)))
    pg.goto(U);pg.wait_for_timeout(800)
    ok('title',pg.title()=='NEXORA')
    for r in ['home','ai','tools','exp','discover','favs']:
        pg.evaluate(f"location.hash='#{r}'");pg.wait_for_timeout(150)
        vis=pg.evaluate("[...document.querySelectorAll('section.pg.on')].map(s=>s.id.slice(2))")
        ok('route '+r,vis==[r],str(vis))
    pg.evaluate("location.hash='#tools'")
    def op(i):
        pg.evaluate(f"location.hash='#{'tools' if i in['calc','conv','timer','text','color','json','pass','file'] else 'exp' if i in['part','light','neon','clock','sound'] else 'ai'}'")
        pg.click(f'[data-o="{i}"]');pg.wait_for_selector('#dlg[open]')
    def cl(): pg.click('#dx');pg.wait_for_timeout(100)
    op('calc')
    for k in ['2','+','3','*','4','=']: pg.click(f'[data-k="{k}"]')
    ok('calc 2+3*4=14',pg.inner_text('#cd')=='14',pg.inner_text('#cd'));pg.click('[data-k="C"]')
    pg.click('[data-k="("]');pg.click('[data-k="="]');ok('calc bad input msg',pg.inner_text('#ce')!='');cl()
    op('conv');pg.fill('#v','100');pg.select_option('#ty','t');pg.select_option('#f','C');pg.select_option('#o','F')
    ok('conv 100C=212F','212' in pg.inner_text('#r'),pg.inner_text('#r'));pg.fill('#v','');ok('conv empty err','Enter a number' in pg.inner_text('#r'));cl()
    op('timer');pg.click('#ts');pg.wait_for_timeout(2200);ok('timer ticks',pg.inner_text('#td')!='25:00',pg.inner_text('#td'));pg.click('#tr');ok('timer reset',pg.inner_text('#td')=='25:00');cl()
    op('text');pg.fill('#tx','  hello   world  ');ok('text count','2 words' in pg.inner_text('#tc'));pg.click('[data-a="u"]');ok('upper',pg.input_value('#tx').strip()=='HELLO   WORLD');pg.click('[data-a="t"]');ok('trim',pg.input_value('#tx')=='HELLO WORLD');cl()
    op('color');pg.evaluate("(()=>{const c=document.querySelector('#cc');c.value='#ff0000';c.dispatchEvent(new Event('input'))})()");t=pg.inner_text('#cp');ok('color palette',len(pg.query_selector_all('#cp button'))==5 and 'rgb(255,0,0)' in t,t[:60]);cl()
    op('json');pg.fill('#jx','{"a":1');pg.click('#jf');ok('json invalid err',pg.query_selector('#jo .err') is not None)
    pg.fill('#jx','{"a":1}');pg.click('#jf');ok('json valid','Valid' in pg.inner_text('#jo'));cl()
    op('pass');pg.fill('#pl','500');pg.click('#pg');ok('pass bad len err','8 to 64' in pg.inner_text('#po'));pg.fill('#pl','24');pg.click('#pg');ok('pass len 24',len(pg.inner_text('#po'))==24);cl()
    open('/tmp/f.txt','w').write('hi');op('file');pg.set_input_files('#fi','/tmp/f.txt');ok('file info','f.txt' in pg.inner_text('#fo') and '2 B' in pg.inner_text('#fo'));cl()
    op('assist');ok('api lab explains','Not connected' in pg.inner_text('#db'));cl()
    for i in ['part','light','neon','clock']:
        op(i);pg.wait_for_timeout(500);pg.mouse.move(700,500);pg.click('#xr,#kr');ok('exp '+i+' reset',True);cl()
    op('sound');pg.click('#sa');pg.wait_for_timeout(600);ok('sound handles no-mic',pg.inner_text('#se')!='',pg.inner_text('#se'));cl()
    # search
    pg.keyboard.press('Control+k');pg.wait_for_selector('#sdlg[open]');pg.keyboard.type('color');pg.keyboard.press('Enter');pg.wait_for_timeout(200)
    ok('ctrl+k opens tool',pg.inner_text('#dt')=='Color Lab',pg.inner_text('#dt'));cl()
    pg.keyboard.press('Control+k');pg.keyboard.type('zzzz');ok('search empty',pg.query_selector('#res li').inner_text()=='No matches');pg.keyboard.press('Escape');ok('esc closes',not pg.evaluate("document.querySelector('#sdlg').open"))
    # favorites + discover
    pg.evaluate("location.hash='#discover'");pg.click('#gD [data-f="calc"]');pg.reload();pg.evaluate("location.hash='#favs'");pg.wait_for_timeout(200)
    ok('favorite persists',pg.query_selector('#gF [data-o="calc"]') is not None)
    pg.evaluate("location.hash='#discover'");pg.fill('#q','zzzz');ok('discover no results','No results' in pg.inner_text('#gD'));pg.click('#rs');ok('reset filters',len(pg.query_selector_all('#gD .card'))==19)
    pg.click('[data-c="Developer Tools"]');ok('category filter',len(pg.query_selector_all('#gD .card'))==3,str(len(pg.query_selector_all('#gD .card'))))
    # settings
    pg.click('#bset');pg.select_option('#sth','light');ok('light theme',pg.evaluate("document.body.classList.contains('lt')"))
    pg.select_option('#sl','ar');pg.wait_for_timeout(300);ok('arabic rtl',pg.evaluate("document.documentElement.dir")=='rtl' and 'الإعدادات' in pg.inner_text('#dt'))
    pg.click('#sc');pg.wait_for_timeout(200);ok('clear data resets',pg.evaluate("document.documentElement.dir")=='ltr' and pg.evaluate("localStorage.getItem('favs')") in (None,'[]'))
    # tampered storage
    pg.evaluate("localStorage.setItem('st','{\"acc\":\"red;}body{display:none\",\"fs\":999}');localStorage.setItem('favs','\"<img>\"')");pg.reload();pg.wait_for_timeout(400)
    ok('tampered storage ignored',pg.evaluate("getComputedStyle(document.body).display")!='none' and pg.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--fs').trim()")=='16px')
    ok('service worker',pg.evaluate("navigator.serviceWorker.ready.then(()=>true)"))
    # responsive
    pg.evaluate("localStorage.clear()")
    for w,h in [(360,740),(390,844),(768,1024),(1024,768),(1440,900)]:
        pg.set_viewport_size({'width':w,'height':h});bad=[]
        for r in ['home','ai','tools','exp','discover','favs']:
            pg.evaluate(f"location.hash='#{r}'");pg.wait_for_timeout(120)
            if pg.evaluate("document.documentElement.scrollWidth>innerWidth+1"):bad.append(r)
        ok(f'no h-scroll {w}px',not bad,str(bad))
        pg.evaluate("location.hash='#home'");pg.wait_for_timeout(300);pg.screenshot(path=f'/tmp/home{w}.png')
    pg.set_viewport_size({'width':390,'height':844});pg.evaluate("location.hash='#tools'");pg.wait_for_timeout(200);pg.screenshot(path='/tmp/tools390.png')
    # offline
    ctx.set_offline(True);pg.reload();pg.wait_for_timeout(500);ok('offline loads',pg.title()=='NEXORA' and pg.evaluate("!!document.querySelector('#gT .card')"))
    b.close()
for n,c,d in R:print('PASS' if c else 'FAIL',n,d if not c else '')
print('console issues:',json.dumps([e for e in err if 'offline' not in e.lower()][:10],ensure_ascii=False))
