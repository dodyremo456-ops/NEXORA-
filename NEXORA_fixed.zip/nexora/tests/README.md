# Tests (Python + Playwright)
Run from this folder with the servers started as shown at the top of e3.py.
e2e.py: static site checks against http://localhost:8765 (python3 -m http.server 8765 in the parent folder).
e3.py: backend, compare lab, About/Privacy and phone touch checks against http://127.0.0.1:8766 (node server.js with test keys and ANTHROPIC_BASE_URL/OPENAI_BASE_URL pointing at fake.py on port 9101).
