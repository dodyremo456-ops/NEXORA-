import json
from http.server import BaseHTTPRequestHandler,HTTPServer
class H(BaseHTTPRequestHandler):
    def log_message(self,*a):pass
    def do_POST(self):
        b=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        open('/tmp/up.log','a').write(json.dumps({'path':self.path,'key':self.headers.get('x-api-key'),'auth':self.headers.get('Authorization'),'ver':self.headers.get('anthropic-version'),'body':b})+'\n')
        txt=json.dumps(b)
        if 'FAIL' in txt:self.send_response(500);self.end_headers();self.wfile.write(b'{"error":"sk-test-LEAK"}');return
        out={"content":[{"type":"text","text":"ANTH-ANSWER"}]} if self.path=='/v1/messages' else {"choices":[{"message":{"content":"OAI-ANSWER"}}]}
        d=json.dumps(out).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(d)));self.end_headers();self.wfile.write(d)
HTTPServer(('127.0.0.1',9101),H).serve_forever()
